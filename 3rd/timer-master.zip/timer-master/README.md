# timer
嵌入式软件通用定时器,
分别实现了数组和链表管理定时器.
将timer_sched();函数放入systick节拍中调度即可
